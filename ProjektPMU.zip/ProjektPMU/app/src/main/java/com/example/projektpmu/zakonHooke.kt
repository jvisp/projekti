package com.example.projektpmu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.projektpmu.databinding.ActivityZakonHookeBinding

class zakonHooke : AppCompatActivity() {
    lateinit var binding: ActivityZakonHookeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)






   binding = ActivityZakonHookeBinding.inflate(layoutInflater)
   setContentView(binding.root)

    binding.nazad.setOnClickListener {
        startActivity(Intent(this@zakonHooke, MainActivity::class.java))
              }


                binding.izracunaj.setOnClickListener {
                    val num1 = binding.konstanta.text.toString().toDouble()
                    val num2 = binding.pomak.text.toString().toDouble()
                    val rezultat = findViewById<TextView>(R.id.rez)
                    val rez1 = -(num1) * num2
                    rezultat.text = "$rez1"
                }
            }
        }





