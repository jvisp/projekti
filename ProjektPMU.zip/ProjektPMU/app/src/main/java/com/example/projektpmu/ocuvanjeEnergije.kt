package com.example.projektpmu

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.projektpmu.databinding.ActivityOcuvanjeEnergijeBinding


class ocuvanjeEnergije : AppCompatActivity() {
    private lateinit var binding: ActivityOcuvanjeEnergijeBinding
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityOcuvanjeEnergijeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.natrag1.setOnClickListener {
            startActivity(Intent(this@ocuvanjeEnergije, MainActivity::class.java))
        }



       binding.izrOcuvanje.setOnClickListener {
            val num1 = binding.kinEng1.text.toString().toDouble()
            val num2 = binding.potEng1.text.toString().toDouble()
            val rezultat = findViewById<TextView>(R.id.ocuvanjeRez)

            val rez = num1 + num2

                     rezultat.text = "$rez"
        }

    }

}
